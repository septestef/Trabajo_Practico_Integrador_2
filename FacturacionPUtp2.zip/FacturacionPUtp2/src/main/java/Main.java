import entidades.*;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.util.ArrayList;
import java.util.Date;

public class Main {

    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("FacturacionPU");
        EntityManager em = emf.createEntityManager();

        try {
            em.getTransaction().begin();

            // 1. Usuario (Auditoría)
            Usuario usuario = new Usuario();
            usuario.setUsuario("admin");
            usuario.setClave("1234");
            usuario.setNombre("Juan");
            usuario.setApellido("Perez");
            em.persist(usuario);

            // 2. Punto de Venta
            PuntoVenta puntoVenta = new PuntoVenta();
            puntoVenta.setNumero(1);
            puntoVenta.setFechaAlta(new Date());
            puntoVenta.setFechaModificacion(new Date());
            puntoVenta.setUsuarioCarga(usuario);
            puntoVenta.setUsuarioModificacion(usuario);
            em.persist(puntoVenta);

            // 3. Crear Articulo y ListaPrecio (Obligatorios para ListaPrecioArticulo)
            Articulo articulo = new Articulo();
            articulo.setCodigo("A001");
            articulo.setDenominacion("Teclado Mecanico");
            articulo.setFechaAlta(new Date());
            articulo.setFechaModificacion(new Date());
            articulo.setUsuarioCarga(usuario);
            articulo.setUsuarioModificacion(usuario);
            em.persist(articulo);

            ListaPrecio listaPrecio = new ListaPrecio();
            listaPrecio.setCodigo("L01");
            listaPrecio.setDenominacion("Lista General");
            listaPrecio.setFechaAlta(new Date());
            listaPrecio.setFechaModificacion(new Date());
            listaPrecio.setUsuarioCarga(usuario);
            listaPrecio.setUsuarioModificacion(usuario);
            em.persist(listaPrecio);

            // 4. ListaPrecioArticulo
            ListaPrecioArticulo listaPrecioArticulo = new ListaPrecioArticulo();
            listaPrecioArticulo.setPrecioVenta(15000.0);
            listaPrecioArticulo.setArticulo(articulo);
            listaPrecioArticulo.setListaPrecio(listaPrecio);
            listaPrecioArticulo.setFechaAlta(new Date());
            listaPrecioArticulo.setFechaModificacion(new Date());
            listaPrecioArticulo.setUsuarioCarga(usuario);
            listaPrecioArticulo.setUsuarioModificacion(usuario);
            em.persist(listaPrecioArticulo);

            // 5. Instanciar y persistir Cliente, CondicionIva y TipoMoneda
            CondicionIva condIva = new CondicionIva();
            condIva.setCodigoAfip(1);
            condIva.setDenominacion("Responsable Inscripto");
            condIva.setFechaAlta(new Date());
            condIva.setFechaModificacion(new Date());
            condIva.setUsuarioCarga(usuario);
            condIva.setUsuarioModificacion(usuario);
            em.persist(condIva);

            TipoMoneda moneda = new TipoMoneda();
            moneda.setCodigoAfip("ARS");
            moneda.setDenominacion("Pesos Argentinos");
            moneda.setSimbolo("$");
            moneda.setFechaAlta(new Date());
            moneda.setFechaModificacion(new Date());
            moneda.setUsuarioCarga(usuario);
            moneda.setUsuarioModificacion(usuario);
            em.persist(moneda);

            Cliente cliente = new Cliente();
            cliente.setCuitCuil("20-12345678-9");
            cliente.setDenominacion("Consumidor Final");
            cliente.setFechaAlta(new Date());
            cliente.setFechaModificacion(new Date());
            cliente.setUsuarioCarga(usuario);
            cliente.setUsuarioModificacion(usuario);

            // Domicilio y Contacto (No necesitan em.persist porque tienen CascadeType.ALL en Cliente)
            Domicilio domicilio = new Domicilio();
            domicilio.setNombreCalle("San Martin");
            domicilio.setNumeroCalle("123");
            cliente.setDomicilio(domicilio);

            Contacto contacto = new Contacto();
            contacto.setEmail("cliente@test.com");
            cliente.setContacto(contacto);

            em.persist(cliente);

            // 6. Crear Cabecera de FacturaVenta
            FacturaVenta facturaVenta = new FacturaVenta();
            facturaVenta.setNumero(1001L);
            facturaVenta.setFechaEmision(new Date());
            facturaVenta.setPuntoVenta(puntoVenta);
            facturaVenta.setImporteTotal(30000.0);
            facturaVenta.setEstado("EMITIDA");

            // Asignar los nuevos atributos requeridos
            facturaVenta.setCliente(cliente);
            facturaVenta.setCondIva(condIva);
            facturaVenta.setMoneda(moneda);

            // Auditoria
            facturaVenta.setFechaAlta(new Date());
            facturaVenta.setFechaModificacion(new Date());
            facturaVenta.setUsuarioCarga(usuario);
            facturaVenta.setUsuarioModificacion(usuario);

            facturaVenta.setDetalles(new ArrayList<>());

            // 7. Crear el Detalle
            FacturaVentaDetalle detalle1 = new FacturaVentaDetalle();
            detalle1.setCantidad(2);
            detalle1.setPrecioUnitario(15000.0);
            detalle1.setImporteSubtotal(30000.0);
            detalle1.setListaPrecioArticulo(listaPrecioArticulo);

            // Relación Bidireccional
            detalle1.setFactura(facturaVenta);
            facturaVenta.getDetalles().add(detalle1);

            // 8. PERSISTIR SOLO LA CABECERA (La magia de CascadeType.ALL insertará los detalles)
            em.persist(facturaVenta);

            em.getTransaction().commit();
            System.out.println("¡Éxito! Se generó la base de datos y se insertó la factura con sus dependencias.");

        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
            emf.close();
        }
    }
}
